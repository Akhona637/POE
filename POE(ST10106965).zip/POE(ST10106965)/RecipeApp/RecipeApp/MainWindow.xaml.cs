﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RecipeApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
       
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }
   

        private void BtnAddRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Show a new window to add recipe
           var addRecipeWindow = new AddRecipeWindow(recipes);
            addRecipeWindow.ShowDialog();
        }

        private void BtnDisplayRecipes_Click(object sender, RoutedEventArgs e)
        {
          lstRecipes.ItemsSource = recipes.OrderBy(r => r.Name).Select(r => r.Name).ToList();
        }

        private void BtnFilterRecipes_Click(object sender, RoutedEventArgs e)
        {
            var filterWindow = new FilterRecipesWindow(recipes);
            filterWindow.ShowDialog();
        }

        private class Recipe
        {
        }
    }

    internal class AddRecipeWindow
    {
        private List<Recipe> recipes;

        public AddRecipeWindow(List<Recipe> recipes)
        {
            this.recipes = recipes;
        }
    }
}
