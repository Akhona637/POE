﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace RecipeApp
{
    public partial class FilterRecipesWindow : Window
    {
        private List<Recipe> recipes;// List to hold all recipes

        public FilterRecipesWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;// Initialize the list with the recipes passed from the main window
        }
        // Event handler for "Filter" button click
        private void BtnFilter_Click(object sender, RoutedEventArgs e)
        {
            // Get filter criteria from text boxes
            string ingredient = txtIngredient.Text.ToLower();
            string foodGroup = txtFoodGroup.Text.ToLower();
            int.TryParse(txtMaxCalories.Text, out int maxCalories);
            // Filter recipes based on criteria
            var filteredRecipes = recipes.Where(r =>
                (string.IsNullOrWhiteSpace(ingredient) || r.Ingredients.Any(i => i.Name.ToLower().Contains(ingredient))) &&
                (string.IsNullOrWhiteSpace(foodGroup) || r.Ingredients.Any(i => i.FoodGroup.ToLower().Contains(foodGroup))) &&
                (maxCalories == 0 || r.CalculateTotalCalories() <= maxCalories)
            ).Select(r => r.Name).ToList();
            // Display filtered recipes in ListBox
            lstFilteredRecipes.ItemsSource = filteredRecipes;
        }
    }
}
